package com.example.practice8calc

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


    }
    var num1:String = ""
    var num2: String = ""
    var symbol = ""
    fun btn00(view: View)
    {
        val btn = view as Button
        val text:TextView = findViewById(R.id.textViewMath)
        when (btn.id) {
            R.id.btn0 -> output("0")
            R.id.btn1 -> output("1")
            R.id.btn2 -> output("2")
            R.id.btn3 -> output("3")
            R.id.btn4 -> output("4")
            R.id.btn5 -> output("5")
            R.id.btn6 -> output("6")
            R.id.btn7 -> output("7")
            R.id.btn8 -> output("8")
            R.id.btn9 -> output("9")

            R.id.btnMulty -> {
                symbol = "*"
                num1 = text.text.toString()
                text.setText("").toString()
            }

            R.id.btnM->{
                        symbol = "-"
                num1 = text.text.toString()
                text.setText("").toString()

            }

            R.id.btnP ->{
                symbol = "+"
                num1 = text.text.toString()
                text.setText("").toString()


            }

            R.id.buttonD-> {
                symbol = "/"
                num1 = text.text.toString()
                text.setText("").toString()

            }

            R.id.buttonC -> text.text = ""
            R.id.btnE -> btnEquals(num1)

        }
    }



    fun output(str:String){

        val text:TextView = findViewById(R.id.textViewMath)
        if(str!="0")
            text.append(str)
        else
            if(text.text.toString()!="0")
                text.append(str)

    }


    fun btnEquals(num1:String){
        val text: TextView = findViewById(R.id.textViewMath)
        var num1= num1
        num2 = text.text.toString()

        if(symbol=="" )
        {
            Toast.makeText(this,"Вы не указали операцию",Toast.LENGTH_SHORT).show();
            return;
        }
        if(num2=="")
        {
            Toast.makeText(this,"Вы не указали второе число",Toast.LENGTH_SHORT).show();
            return;
        }

        if(num1!="")
        {
            when(symbol){
                "+" -> if((num1.toDouble() + num2.toDouble())%1==0.0)
                    text.text ="${(num1.toInt() + num2.toInt())}"
                else
                    text.text ="${(num1.toDouble() + num2.toDouble())}"

                "-" ->if((num1.toDouble() + num2.toDouble())%1==0.0)
                    text.text ="${(num1.toInt() - num2.toInt())}"
                else
                    text.text ="${(num1.toDouble() - num2.toDouble())}"


                "*" -> if((num1.toDouble() + num2.toDouble())%1==0.0)
                    text.text ="${(num1.toInt() * num2.toInt())}"
                else
                    text.text ="${(num1.toDouble() * num2.toDouble())}"


                "/" -> {
                    if(num2.toInt()!=0){
                        text.text = "${(num1.toDouble() / num2.toDouble())}"
                    }
                    else {
                        Toast.makeText(this,"Ошибка деления на ноль",Toast.LENGTH_LONG).show();
                        text.setText("");
                        num1="";
                        num2="";
                        symbol="";
                    }

                }
            }
        }
        else
        {
            Toast.makeText(this,"Не указано первое число",Toast.LENGTH_LONG).show();
            text.setText("");
        }
        num1="";
        num2="";
        symbol="";
    }
}